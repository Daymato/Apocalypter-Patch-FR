"""Build the localization payload from the original extracted assets and textes-fr.json.
No game executable is launched. Originals are opened read-only.
"""
import argparse
import collections
import gzip
import hashlib
import io
import json
import struct
from pathlib import Path

import UnityPy
from UnityPy.helpers import TypeTreeHelper
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
from UnityPy.streams import EndianBinaryReader, EndianBinaryWriter

HERE = Path(__file__).resolve().parent


def field(tree, path):
    for key in path:
        tree = tree[key]
    return tree


def assign(tree, path, value):
    field(tree, path[:-1])[path[-1]] = value


def object_table(data):
    if struct.unpack_from('>I', data, 8)[0] != 22:
        raise ValueError('Format de fichier Unity inattendu.')
    pos = data.index(0, 48) + 1 + 4
    if data[pos] != 0:
        raise ValueError('Ce script attend les fichiers originaux sans type tree.')
    pos += 1
    count = struct.unpack_from('<I', data, pos)[0]
    pos += 4
    for _ in range(count):
        class_id = struct.unpack_from('<i', data, pos)[0]
        pos += 7 + (16 if class_id == 114 else 0) + 16
    count = struct.unpack_from('<I', data, pos)[0]
    pos += 4
    rows = []
    for _ in range(count):
        pos = (pos + 3) & ~3
        path_id, offset, size, _ = struct.unpack_from('<qqIi', data, pos)
        rows.append((path_id, offset, size, pos))
        pos += 24
    return sorted(rows, key=lambda row: row[1])


def build_edits(original, replacements):
    base = struct.unpack_from('>q', original, 32)[0]
    rows = object_table(original)
    edits = []
    delta = 0
    for index, (path_id, offset, size, entry) in enumerate(rows):
        if delta:
            edits.append((entry + 8, 8, struct.pack('<q', offset + delta)))
        if path_id not in replacements:
            continue
        replacement = replacements[path_id]
        if len(replacement) != size:
            edits.append((entry + 16, 4, struct.pack('<I', len(replacement))))
        start = base + offset
        end = base + rows[index + 1][1] if index + 1 < len(rows) else len(original)
        if any(original[start + size:end]):
            raise ValueError('Donnees inattendues entre deux objets Unity.')
        replacement += bytes((-(offset + delta + len(replacement))) % 8)
        edits.append((start, end - start, replacement))
        delta += len(replacement) - (end - start)
    edits.append((24, 8, struct.pack('>q', len(original) + delta)))
    merged = []
    for offset, size, value in sorted(edits):
        if merged and merged[-1][0] + merged[-1][1] == offset and merged[-1][0] < base and offset < base:
            prev = merged.pop()
            merged.append((prev[0], prev[1] + size, prev[2] + value))
        else:
            merged.append((offset, size, value))
    result = io.BytesIO()
    cursor = 0
    for offset, size, value in merged:
        if offset < cursor:
            raise ValueError('Modifications superposees.')
        result.write(original[cursor:offset])
        result.write(value)
        cursor = offset + size
    result.write(original[cursor:])
    return merged, result.getvalue()


def main():
    parser = argparse.ArgumentParser(description='Regenerer le patch FR d\'Apocalypter.')
    parser.add_argument('--extraits', required=True, type=Path, help='Dossier des fichiers extraits originaux.')
    parser.add_argument('--managed', required=True, type=Path, help='Dossier Apocalypter_Data/Managed original.')
    parser.add_argument('--textes', type=Path, default=HERE.parent / 'textes-fr.json')
    parser.add_argument('--sortie', type=Path, default=HERE.parent / 'patch-fr.dat.gz')
    args = parser.parse_args()
    catalog = json.loads(args.textes.read_text(encoding='utf-8'))
    if catalog['format'] != 1:
        raise ValueError('Format du catalogue inconnu.')
    env = UnityPy.Environment()
    files = {}
    for name, expected in catalog['fichiers_originaux'].items():
        path = args.extraits / name
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Version incompatible : ' + name)
        files[name] = env.load_file(str(path))
    generator = TypeTreeGenerator(catalog['version_unity'])
    generator.load_local_dll_folder(str(args.managed))
    node_cache = {}

    def node_for(obj):
        script = obj.parse_monobehaviour_head().m_Script.deref_parse_as_object()
        full_name = (script.m_Namespace + '.' if script.m_Namespace else '') + script.m_ClassName
        key = (script.m_AssemblyName, full_name)
        if key not in node_cache:
            nodes = json.loads(generator.get_nodes_as_json(*key))
            # Correct two metadata ambiguities of this Unity build / generator.
            for index, node in enumerate(nodes):
                if node['m_Name'] == 'm_Enabled' and node['m_Level'] == 1:
                    node['m_MetaFlag'] |= 0x4000
                if node['m_Type'] == 'string' and index + 3 < len(nodes) and nodes[index + 1]['m_Type'] == 'Array' and nodes[index + 3]['m_Type'] == 'string':
                    node['m_Type'] = 'vector'
            node_cache[key] = TypeTreeNode.from_list(nodes)
        return node_cache[key]

    grouped = collections.defaultdict(list)
    for translation in catalog['traductions']:
        source, french = translation['source'], translation['fr']
        if not isinstance(french, str):
            raise ValueError('Une traduction doit etre une chaine de caracteres.')
        if source == french:
            continue
        if not french.isascii():
            raise ValueError('La traduction doit rester sans accents : ' + repr(french))
        for occurrence in translation['occurrences']:
            grouped[occurrence['fichier'], occurrence['path_id']].append((occurrence['champ'], source, french))

    replacements = collections.defaultdict(dict)
    occurrences = 0
    for (name, path_id), changes in grouped.items():
        assets = files[name]
        obj = assets.objects[path_id]
        node = node_for(obj)
        tree = obj.read_typetree(node)
        writer = EndianBinaryWriter(endian='<')
        TypeTreeHelper.write_typetree(tree, node, writer, assets)
        if writer.bytes != obj.get_raw_data():
            raise ValueError('Reecriture non identique avant traduction : %s/%s' % (name, path_id))
        for path, source, french in changes:
            if field(tree, path) != source:
                raise ValueError('Texte original inattendu : %s/%s' % (name, path_id))
            assign(tree, path, french)
            occurrences += 1
        writer = EndianBinaryWriter(endian='<')
        TypeTreeHelper.write_typetree(tree, node, writer, assets)
        data = writer.bytes
        reread = TypeTreeHelper.read_typetree(node, EndianBinaryReader(data, endian='<'), as_dict=True, assetsfile=assets, byte_size=len(data), check_read=True)
        for path, source, french in changes:
            if field(reread, path) != french:
                raise ValueError('Verification de traduction echouee.')
        replacements[name][path_id] = data

    if not replacements:
        raise ValueError('Aucune traduction differente du texte original.')
    payload = io.BytesIO()
    payload.write(b'AFRPAT01')
    payload.write(struct.pack('<i', len(replacements)))
    for name in sorted(replacements):
        original = (args.extraits / name).read_bytes()
        edits, result = build_edits(original, replacements[name])
        encoded = name.encode('utf-8')
        payload.write(struct.pack('<i', len(encoded)))
        payload.write(encoded)
        payload.write(hashlib.sha256(original).digest())
        payload.write(hashlib.sha256(result).digest())
        payload.write(struct.pack('<qqi', len(original), len(result), len(edits)))
        for offset, size, data in edits:
            payload.write(struct.pack('<qii', offset, size, len(data)))
            payload.write(data)
        print('%s : %d objets modifies' % (name, len(replacements[name])))
    args.sortie.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.sortie.with_name(args.sortie.name + '.tmp')
    try:
        with temporary.open('wb') as stream:
            with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
                compressed.write(payload.getvalue())
        temporary.replace(args.sortie)
    finally:
        if temporary.exists():
            temporary.unlink()
    print('%d textes modifies. Patch cree : %s' % (occurrences, args.sortie))


if __name__ == '__main__':
    main()
