@echo off
setlocal
cd /d "%~dp0"
set "compiler=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%compiler%" set "compiler=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%compiler%" (
  echo Compilateur .NET Framework introuvable.
  pause
  exit /b 1
)
"%compiler%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"..\Apocalypter_Patch_FR.exe" /reference:"..\SharpCompress.dll" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll PatchCore.cs Program.cs
if errorlevel 1 (
  echo Compilation echouee.
  pause
  exit /b 1
)
echo Programme compile.
pause
endlocal
