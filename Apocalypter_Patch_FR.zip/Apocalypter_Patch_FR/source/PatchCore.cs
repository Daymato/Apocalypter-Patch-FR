using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using SharpCompress.Compressors.LZMA;

namespace ApocalypterFR {
  public sealed class SliceStream : Stream {
    readonly Stream inner; long remaining;
    public SliceStream(Stream stream, long count) { inner=stream; remaining=count; }
    public override int Read(byte[] b,int off,int count) { int n=inner.Read(b,off,(int)Math.Min(count,remaining)); remaining-=n; return n; }
    public override bool CanRead { get { return true; } }
    public override bool CanSeek { get { return false; } }
    public override bool CanWrite { get { return false; } }
    public override long Length { get { throw new NotSupportedException(); } }
    public override long Position { get { throw new NotSupportedException(); } set { throw new NotSupportedException(); } }
    public override void Flush() {}
    public override long Seek(long x,SeekOrigin y) { throw new NotSupportedException(); }
    public override void SetLength(long x) { throw new NotSupportedException(); }
    public override void Write(byte[] b,int o,int n) { throw new NotSupportedException(); }
  }
  public static class BinaryUtil {
    public static byte[] Bytes(Stream s,int n) { if(n<0)throw new InvalidDataException(); byte[] b=new byte[n]; int p=0; while(p<n) { int k=s.Read(b,p,n-p);if(k==0)throw new EndOfStreamException();p+=k; } return b; }
    public static uint U32(Stream s) { byte[] b=Bytes(s,4); return ((uint)b[0]<<24)|((uint)b[1]<<16)|((uint)b[2]<<8)|b[3]; }
    public static ulong U64(Stream s) { return ((ulong)U32(s)<<32)|U32(s); }
    public static ushort U16(Stream s) { byte[] b=Bytes(s,2);return (ushort)((b[0]<<8)|b[1]); }
    public static void W32(Stream s,uint x) { s.WriteByte((byte)(x>>24));s.WriteByte((byte)(x>>16));s.WriteByte((byte)(x>>8));s.WriteByte((byte)x); }
    public static void W64(Stream s,ulong x) { W32(s,(uint)(x>>32));W32(s,(uint)x); }
    public static void W16(Stream s,ushort x) { s.WriteByte((byte)(x>>8));s.WriteByte((byte)x); }
    public static string CString(Stream s) { using(var m=new MemoryStream()) { int c;while((c=s.ReadByte())>0) { if(m.Length>4096)throw new InvalidDataException("Nom d'entree trop long.");m.WriteByte((byte)c); } if(c<0)throw new EndOfStreamException();return Encoding.UTF8.GetString(m.ToArray()); } }
    public static void WCString(Stream s,string v) { byte[] b=Encoding.UTF8.GetBytes(v);s.Write(b,0,b.Length);s.WriteByte(0); }
    public static void Align(Stream s,int align) { s.Position=(s.Position+align-1)/align*align; }
    public static void Pad(Stream s,int align) { while(s.Position%align!=0)s.WriteByte(0); }
    public static void Copy(Stream source,Stream dest,long length) { byte[] buffer=new byte[1024*1024];while(length>0) {int n=source.Read(buffer,0,(int)Math.Min(buffer.Length,length));if(n==0)throw new EndOfStreamException();dest.Write(buffer,0,n);length-=n;} }
    public static byte[] Hash(Stream stream,long length) { using(var sha=SHA256.Create())return sha.ComputeHash(new SliceStream(stream,length)); }
    public static string FileHash(string file) { using(var s=File.OpenRead(file)) return Hex(Hash(s,s.Length)); }
    public static string Hex(byte[] b) { return BitConverter.ToString(b).Replace("-","").ToLowerInvariant(); }
    public static bool Same(byte[] a,byte[] b) { if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true; }
  }
  public static class Lz4 {
    static uint Word(byte[] b,int i) { return (uint)(b[i]|(b[i+1]<<8)|(b[i+2]<<16)|(b[i+3]<<24)); }
    static int Hash(uint x) { return (int)((x*2654435761u)>>16); }
    static void Length(List<byte> b,int x) { while(x>=255) { b.Add(255);x-=255; }b.Add((byte)x); }
    public static byte[] Encode(byte[] src,int n) {
      var dst=new List<byte>(n+32);int[] table=new int[65536];for(int k=0;k<table.Length;k++)table[k]=-1;
      int ip=0,anchor=0;
      while(ip<=n-12) {
        int h=Hash(Word(src,ip)),reference=table[h];table[h]=ip;
        if(reference<0||ip-reference>65535||Word(src,reference)!=Word(src,ip)) {ip++;continue;}
        int end=ip+4;while(end<n-5&&src[reference+end-ip]==src[end])end++;
        int literals=ip-anchor,match=end-ip-4;
        dst.Add((byte)((Math.Min(literals,15)<<4)|Math.Min(match,15)));
        if(literals>=15)Length(dst,literals-15);
        for(int k=anchor;k<ip;k++)dst.Add(src[k]);
        int distance=ip-reference;dst.Add((byte)distance);dst.Add((byte)(distance>>8));
        if(match>=15)Length(dst,match-15);
        ip=end;anchor=ip;
        if(ip-2>=0&&ip-2<=n-4)table[Hash(Word(src,ip-2))]=ip-2;
      }
      int tail=n-anchor;dst.Add((byte)(Math.Min(tail,15)<<4));if(tail>=15)Length(dst,tail-15);
      for(int k=anchor;k<n;k++)dst.Add(src[k]);return dst.ToArray();
    }
    public static byte[] Decode(byte[] src,int expected) {
      byte[] dst=new byte[expected];int ip=0,op=0;
      while(ip<src.Length) {
        int token=src[ip++],literal=token>>4;
        if(literal==15) {int x;do {if(ip>=src.Length)throw new InvalidDataException("LZ4 incomplet.");x=src[ip++];literal=checked(literal+x);}while(x==255);}
        if(literal>src.Length-ip||literal>expected-op)throw new InvalidDataException("LZ4 invalide.");
        Buffer.BlockCopy(src,ip,dst,op,literal);ip+=literal;op+=literal;
        if(ip==src.Length)break;
        if(ip+2>src.Length)throw new InvalidDataException("LZ4 incomplet.");
        int distance=src[ip]|(src[ip+1]<<8);ip+=2;if(distance==0||distance>op)throw new InvalidDataException("Distance LZ4 invalide.");
        int match=(token&15)+4;
        if((token&15)==15) {int x;do {if(ip>=src.Length)throw new InvalidDataException("LZ4 incomplet.");x=src[ip++];match=checked(match+x);}while(x==255);}
        if(match>expected-op)throw new InvalidDataException("Taille LZ4 invalide.");
        for(int j=0;j<match;j++) {dst[op]=dst[op-distance];op++;}
      }
      if(op!=expected)throw new InvalidDataException("Taille decompressee incorrecte.");return dst;
    }
  }
  public sealed class BundleNode { public long Offset,Size;public uint Flags;public string Name;public string Replacement; }
  public sealed class BundleBlock { public uint Raw,Stored;public ushort Flags; }
  public sealed class BundleInfo {
    public uint Version,Flags; public string Player,Engine; public long DataStart,TotalRaw;
    public List<BundleNode> Nodes=new List<BundleNode>();public List<BundleBlock> Blocks=new List<BundleBlock>();
    public bool AlignedHeader { get { if(Version>=7)return true;int patch;return Engine.StartsWith("2019.4.")&&Int32.TryParse(System.Text.RegularExpressions.Regex.Match(Engine.Substring(7),@"^\d+").Value,out patch)&&patch>=15; } }
    static byte[] DecodeInfo(byte[] compressed,int size,int mode) {
      if(mode==0) {if(compressed.Length!=size)throw new InvalidDataException();return compressed;}
      if(mode==2||mode==3)return Lz4.Decode(compressed,size);
      if(mode==1) {
        if(compressed.Length<5)throw new InvalidDataException();byte[] props=new byte[5];Buffer.BlockCopy(compressed,0,props,0,5);
        using(var input=new MemoryStream(compressed,5,compressed.Length-5))
        // Unity supplies the decoded size in its block table. Stop at that size;
        // raw LZMA streams may include or omit an end marker.
        using(var lz=new LzmaStream(props,input,-1,-1))return BinaryUtil.Bytes(lz,size);
      }
      throw new InvalidDataException("Compression Unity non prise en charge : "+mode);
    }
    public static BundleInfo Read(Stream s) {
      s.Position=0;if(BinaryUtil.CString(s)!="UnityFS")throw new InvalidDataException("Le fichier n'est pas un bundle UnityFS.");
      var r=new BundleInfo();r.Version=BinaryUtil.U32(s);r.Player=BinaryUtil.CString(s);r.Engine=BinaryUtil.CString(s);
      long total=checked((long)BinaryUtil.U64(s));uint compressed=BinaryUtil.U32(s),raw=BinaryUtil.U32(s);r.Flags=BinaryUtil.U32(s);
      if(total!=s.Length||r.Version<6||r.Version>8||compressed>64*1024*1024||raw>64*1024*1024)throw new InvalidDataException("En-tete Unity inattendue.");
      if((r.Flags&0x1400)!=0)throw new InvalidDataException("Bundle chiffre non pris en charge.");
      if(r.AlignedHeader)BinaryUtil.Align(s,16);
      long start=s.Position;
      if((r.Flags&0x80)!=0)s.Position=s.Length-compressed;
      byte[] info=DecodeInfo(BinaryUtil.Bytes(s,(int)compressed),(int)raw,(int)(r.Flags&63));
      r.DataStart=(r.Flags&0x80)!=0?start:s.Position;
      if((r.Flags&0x200)!=0)r.DataStart=(r.DataStart+15)/16*16;
      using(var m=new MemoryStream(info)) {
        BinaryUtil.Bytes(m,16);int count=checked((int)BinaryUtil.U32(m));if(count<0||count>1000000)throw new InvalidDataException();
        for(int i=0;i<count;i++) {var b=new BundleBlock {Raw=BinaryUtil.U32(m),Stored=BinaryUtil.U32(m),Flags=BinaryUtil.U16(m)};r.Blocks.Add(b);r.TotalRaw+=b.Raw;}
        count=checked((int)BinaryUtil.U32(m));if(count<0||count>100000)throw new InvalidDataException();
        var names=new HashSet<string>(StringComparer.Ordinal);
        for(int i=0;i<count;i++) {
          var n=new BundleNode {Offset=checked((long)BinaryUtil.U64(m)),Size=checked((long)BinaryUtil.U64(m)),Flags=BinaryUtil.U32(m),Name=BinaryUtil.CString(m)};
          if(n.Offset<0||n.Size<0||n.Offset>r.TotalRaw-n.Size||!names.Add(n.Name))throw new InvalidDataException("Entree Unity invalide.");r.Nodes.Add(n);
        }
        if(m.Position!=m.Length)throw new InvalidDataException("Table Unity inattendue.");
      }
      long bytes=0;foreach(var b in r.Blocks)bytes+=b.Stored;
      if(r.DataStart+bytes>(((r.Flags&0x80)!=0)?s.Length-compressed:s.Length))throw new InvalidDataException("Blocs Unity incomplets.");
      return r;
    }
    public void Unpack(Stream input,string path,Action<string> log) {
      input.Position=DataStart;long done=0,last=0;
      using(var output=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None,1024*1024)) {
        foreach(var block in Blocks) {
          long end=input.Position+block.Stored;int mode=block.Flags&63;
          if(mode==0) {if(block.Raw!=block.Stored)throw new InvalidDataException();BinaryUtil.Copy(input,output,block.Raw);}
          else if(mode==2||mode==3) {
            if(block.Stored>512*1024*1024||block.Raw>512*1024*1024)throw new InvalidDataException("Bloc LZ4 anormalement grand.");
            byte[] data=Lz4.Decode(BinaryUtil.Bytes(input,(int)block.Stored),(int)block.Raw);output.Write(data,0,data.Length);
          } else if(mode==1) {
            if(block.Stored<5)throw new InvalidDataException();byte[] props=BinaryUtil.Bytes(input,5);
            using(var limited=new SliceStream(input,block.Stored-5))
            using(var lz=new LzmaStream(props,limited,-1,-1))BinaryUtil.Copy(lz,output,block.Raw);
          } else throw new InvalidDataException("Compression non prise en charge : "+mode);
          input.Position=end;done+=block.Raw;
          if(done-last>=64*1024*1024) {log("Extraction : "+(done*100/Math.Max(1,TotalRaw))+" %");last=done;}
        }
        if(output.Length!=TotalRaw)throw new InvalidDataException("Extraction incomplete.");
      }
    }
  }
  public sealed class Edit { public long Offset;public int Old;public byte[] Data; }
  public sealed class AssetPatch {
    public string Name; public byte[] Before,After;public long OldSize,NewSize;public List<Edit> Edits=new List<Edit>();
    static string ReadString(BinaryReader r) {int n=r.ReadInt32();if(n<0||n>4096)throw new InvalidDataException();return Encoding.UTF8.GetString(BinaryUtil.Bytes(r.BaseStream,n));}
    public static List<AssetPatch> ReadAll(string path) {
      var list=new List<AssetPatch>();
      using(var file=File.OpenRead(path))using(var gzip=new GZipStream(file,CompressionMode.Decompress))using(var r=new BinaryReader(gzip)) {
        if(Encoding.ASCII.GetString(BinaryUtil.Bytes(gzip,8))!="AFRPAT01")throw new InvalidDataException("Patch inconnu.");
        int count=r.ReadInt32();if(count<1||count>100)throw new InvalidDataException();
        for(int i=0;i<count;i++) {
          var p=new AssetPatch {Name=ReadString(r),Before=BinaryUtil.Bytes(gzip,32),After=BinaryUtil.Bytes(gzip,32),OldSize=r.ReadInt64(),NewSize=r.ReadInt64()};
          int n=r.ReadInt32();if(n<0||n>1000000||p.OldSize<0||p.NewSize<0)throw new InvalidDataException();long cursor=0;
          for(int j=0;j<n;j++) {
            long off=r.ReadInt64();int old=r.ReadInt32(),size=r.ReadInt32();
            if(off<cursor||old<0||size<0||size>64*1024*1024||off>p.OldSize-old)throw new InvalidDataException("Modification invalide.");
            p.Edits.Add(new Edit {Offset=off,Old=old,Data=BinaryUtil.Bytes(gzip,size)});cursor=off+old;
          }
          list.Add(p);
        }
        if(gzip.ReadByte()!=-1)throw new InvalidDataException("Donnees superflues dans le patch.");
      }
      return list;
    }
    public void Apply(Stream source,long offset,long size,string dest) {
      if(size!=OldSize)throw new InvalidDataException("Version incompatible : "+Name);
      source.Position=offset;if(!BinaryUtil.Same(BinaryUtil.Hash(source,size),Before))throw new InvalidDataException("Version incompatible : "+Name+". Aucun fichier du jeu n'a ete modifie.");
      source.Position=offset;long cursor=0;
      using(var output=new FileStream(dest,FileMode.CreateNew)) {
        foreach(var edit in Edits) {
          BinaryUtil.Copy(source,output,edit.Offset-cursor);source.Position+=edit.Old;output.Write(edit.Data,0,edit.Data.Length);cursor=edit.Offset+edit.Old;
        }
        BinaryUtil.Copy(source,output,size-cursor);
        if(output.Length!=NewSize)throw new InvalidDataException("Taille du resultat incorrecte : "+Name);
      }
      if(BinaryUtil.FileHash(dest)!=BinaryUtil.Hex(After))throw new InvalidDataException("Verification du resultat echouee : "+Name);
    }
  }
  public sealed class ChunkWriter {
    readonly Stream output;readonly byte[] buffer=new byte[1024*1024];int used;readonly MD5 md5=MD5.Create();
    public long Total;public List<BundleBlock> Blocks=new List<BundleBlock>();public byte[] Digest;
    public ChunkWriter(Stream stream) {output=stream;}
    public void Write(byte[] data,int off,int count) {while(count>0) {int n=Math.Min(count,buffer.Length-used);Buffer.BlockCopy(data,off,buffer,used,n);used+=n;off+=n;count-=n;Total+=n;if(used==buffer.Length)FlushBlock();}}
    public void Copy(Stream source,long offset,long count) {source.Position=offset;while(count>0) {int n=source.Read(buffer,used,(int)Math.Min(count,buffer.Length-used));if(n==0)throw new EndOfStreamException();used+=n;count-=n;Total+=n;if(used==buffer.Length)FlushBlock();}}
    public void Align() {int n=(int)((16-Total%16)%16);if(n>0)Write(new byte[n],0,n);}
    void FlushBlock() {
      if(used==0)return;md5.TransformBlock(buffer,0,used,buffer,0);byte[] compressed=Lz4.Encode(buffer,used);
      if(compressed.Length<used) {output.Write(compressed,0,compressed.Length);Blocks.Add(new BundleBlock {Raw=(uint)used,Stored=(uint)compressed.Length,Flags=2});}
      else {output.Write(buffer,0,used);Blocks.Add(new BundleBlock {Raw=(uint)used,Stored=(uint)used,Flags=0});}
      used=0;
    }
    public void Finish() {FlushBlock();md5.TransformFinalBlock(new byte[0],0,0);Digest=md5.Hash;md5.Dispose();}
  }
  public static class PatchEngine {
    [System.Runtime.InteropServices.DllImport("libc",EntryPoint="rename",SetLastError=true)]
    static extern int UnixRename(string source,string destination);
    public static void Rebuild(string source,string dest,string payload,string temp,Action<string> log) {
      Directory.CreateDirectory(temp);var patches=AssetPatch.ReadAll(payload);BundleInfo original;
      using(var input=File.OpenRead(source)) {original=BundleInfo.Read(input);original.Unpack(input,Path.Combine(temp,"original.raw"),log);}
      using(var raw=File.OpenRead(Path.Combine(temp,"original.raw"))) {
        foreach(var patch in patches) {
          BundleNode node=original.Nodes.Find(n=>n.Name==patch.Name||n.Name.EndsWith("/"+patch.Name,StringComparison.Ordinal));
          if(node==null)throw new InvalidDataException("Entree absente : "+patch.Name);
          log("Traduction : "+patch.Name);string result=Path.Combine(temp,"patched-"+patch.Name.Replace('/','_'));
          patch.Apply(raw,node.Offset,node.Size,result);node.Replacement=result;
        }
        using(var output=new FileStream(dest,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None,1024*1024)) {
          BinaryUtil.WCString(output,"UnityFS");BinaryUtil.W32(output,original.Version);BinaryUtil.WCString(output,original.Player);BinaryUtil.WCString(output,original.Engine);
          long header=output.Position;BinaryUtil.W64(output,0);BinaryUtil.W32(output,0);BinaryUtil.W32(output,0);BinaryUtil.W32(output,0xC0);
          if(original.AlignedHeader)BinaryUtil.Pad(output,16);
          var writer=new ChunkWriter(output);var nodes=new List<BundleNode>(original.Nodes);nodes.Sort((a,b)=>a.Offset.CompareTo(b.Offset));long last=0;
          foreach(var node in nodes) {
            writer.Align();long sourceOffset=node.Offset;node.Offset=writer.Total;
            if(node.Replacement!=null) {using(var replacement=File.OpenRead(node.Replacement)) {node.Size=replacement.Length;writer.Copy(replacement,0,replacement.Length);}}
            else writer.Copy(raw,sourceOffset,node.Size);
            if(writer.Total-last>=64*1024*1024) {log("Reconstruction : "+Math.Min(99,writer.Total*100/Math.Max(1,original.TotalRaw))+" %");last=writer.Total;}
          }
          writer.Finish();
          using(var info=new MemoryStream()) {
            info.Write(writer.Digest,0,16);BinaryUtil.W32(info,(uint)writer.Blocks.Count);
            foreach(var block in writer.Blocks) {BinaryUtil.W32(info,block.Raw);BinaryUtil.W32(info,block.Stored);BinaryUtil.W16(info,block.Flags);}
            BinaryUtil.W32(info,(uint)original.Nodes.Count);
            foreach(var node in original.Nodes) {BinaryUtil.W64(info,(ulong)node.Offset);BinaryUtil.W64(info,(ulong)node.Size);BinaryUtil.W32(info,node.Flags);BinaryUtil.WCString(info,node.Name);}
            byte[] bytes=info.ToArray();output.Write(bytes,0,bytes.Length);long size=output.Length;
            output.Position=header;BinaryUtil.W64(output,(ulong)size);BinaryUtil.W32(output,(uint)bytes.Length);BinaryUtil.W32(output,(uint)bytes.Length);output.Flush();
          }
        }
      }
      using(var verify=File.OpenRead(dest)) {BundleInfo read=BundleInfo.Read(verify);if(read.Nodes.Count!=original.Nodes.Count)throw new InvalidDataException("Bundle incomplet.");}
      log("Reconstruction terminee.");
    }
    public static void ReplaceFile(string candidate,string target) {
      // Windows uses an atomic replacement on the same volume.
      if(Environment.OSVersion.Platform==PlatformID.Unix) {
        if(UnixRename(candidate,target)!=0)throw new System.ComponentModel.Win32Exception(System.Runtime.InteropServices.Marshal.GetLastWin32Error());
        return;
      }
      if(Environment.OSVersion.Platform==PlatformID.Win32NT) {
        try {File.Replace(candidate,target,null);return;}catch(PlatformNotSupportedException) {}
      }
      string staging=target+".swap-"+Guid.NewGuid().ToString("N");File.Move(target,staging);
      try {File.Move(candidate,target);}catch {File.Move(staging,target);throw;}
      try {File.Delete(staging);}catch {}
    }
    public static void Install(string game,string payload,Action<string> log) {
      string target=Path.Combine(game,"Apocalypter_Data","data.unity3d");
      if(!File.Exists(Path.Combine(game,"Apocalypter.exe"))||!File.Exists(target))throw new IOException("Selectionnez le dossier qui contient Apocalypter.exe.");
      if(System.Diagnostics.Process.GetProcessesByName("Apocalypter").Length>0)throw new IOException("Fermez Apocalypter avant d'appliquer le patch.");
      string backup=target+".avant-fr",state=target+".etat-fr";log("Verification du fichier actuel...");string before=BinaryUtil.FileHash(target);
      if(File.Exists(backup)) {
        if(File.Exists(state)) {string[] fields=File.ReadAllLines(state);if(fields.Length>=2&&before==fields[1]) {log("Le patch francais est deja installe.");return;}}
        if(BinaryUtil.FileHash(backup)!=before)throw new IOException("Une sauvegarde d'une autre version existe deja : data.unity3d.avant-fr. Conservez-la ailleurs avant de continuer.");
      }
      string temp=Path.Combine(Path.GetDirectoryName(target),".patch-fr-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
      try {
        string snapshot=Path.Combine(temp,"source.unity3d");log("Copie de travail...");File.Copy(target,snapshot);
        if(BinaryUtil.FileHash(snapshot)!=before)throw new IOException("La copie de travail ne correspond pas au jeu.");
        string candidate=Path.Combine(temp,"data.unity3d.fr");Rebuild(snapshot,candidate,payload,temp,log);string after=BinaryUtil.FileHash(candidate);
        if(BinaryUtil.FileHash(target)!=before)throw new IOException("Le jeu a change pendant la reconstruction. Relancez le patch.");
        if(!File.Exists(backup)) {log("Sauvegarde de l'anglais...");File.Move(snapshot,backup);}
        // Commit the recovery information first. A failure here leaves the game in English.
        string stateCopy=Path.Combine(temp,"state.txt");File.WriteAllLines(stateCopy,new string[] {before,after});
        if(File.Exists(state))ReplaceFile(stateCopy,state);else File.Move(stateCopy,state);
        if(BinaryUtil.FileHash(target)!=before)throw new IOException("Le jeu a change avant l'installation. Relancez le patch.");
        log("Installation...");ReplaceFile(candidate,target);log("FRANCAIS INSTALLE. Vous pouvez lancer le jeu.");
      } finally {try {Directory.Delete(temp,true);}catch {}}
    }
    public static void Restore(string game,Action<string> log) {
      string target=Path.Combine(game,"Apocalypter_Data","data.unity3d"),backup=target+".avant-fr",state=target+".etat-fr";
      if(!File.Exists(backup)||!File.Exists(target))throw new IOException("Aucune sauvegarde anglaise n'a ete trouvee.");
      if(System.Diagnostics.Process.GetProcessesByName("Apocalypter").Length>0)throw new IOException("Fermez Apocalypter avant de restaurer l'anglais.");
      string original=BinaryUtil.FileHash(backup),current=BinaryUtil.FileHash(target);
      if(current==original) {log("Le jeu est deja en anglais.");return;}
      if(!File.Exists(state))throw new IOException("L'etat du patch est absent. Restaurez manuellement votre sauvegarde si necessaire.");
      string[] fields=File.ReadAllLines(state);if(fields.Length<2||fields[0]!=original||fields[1]!=current)throw new IOException("Les fichiers ont change depuis l'installation. La restauration automatique a ete arretee.");
      string candidate=target+".restore-"+Guid.NewGuid().ToString("N");
      try {log("Restauration de l'anglais...");File.Copy(backup,candidate);if(BinaryUtil.FileHash(candidate)!=original)throw new IOException("Copie incorrecte.");ReplaceFile(candidate,target);log("ANGLAIS RESTAURE.");}
      finally {if(File.Exists(candidate))File.Delete(candidate);}
    }
  }
}
