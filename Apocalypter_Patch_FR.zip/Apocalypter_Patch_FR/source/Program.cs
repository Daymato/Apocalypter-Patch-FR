using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace ApocalypterFR {
  public sealed class MainWindow : Form {
    TextBox folder,output;Button browse,install,restore;ProgressBar progress;Label status;bool working;
    public MainWindow() {
      Text="Apocalypter - Patch francais";ClientSize=new Size(740,490);MinimumSize=new Size(650,440);
      StartPosition=FormStartPosition.CenterScreen;Font=new Font("Segoe UI",10);BackColor=Color.FromArgb(246,247,249);
      var title=new Label {Text="APOCALYPTER / PATCH FR",Font=new Font("Segoe UI",19,FontStyle.Bold),Location=new Point(22,19),Size=new Size(680,38)};Controls.Add(title);
      Controls.Add(new Label {Text="Textes sans accents. Version de test : rendu a verifier dans le jeu.",Location=new Point(24,64),Size=new Size(680,26)});
      Controls.Add(new Label {Text="Dossier contenant Apocalypter.exe",Location=new Point(24,107),Size=new Size(680,24)});
      folder=new TextBox {Location=new Point(24,135),Size=new Size(572,27),Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right};
      string guess=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Apocalypter");
      folder.Text=Directory.Exists(guess)?guess:"";Controls.Add(folder);
      browse=new Button {Text="Parcourir...",Location=new Point(610,133),Size=new Size(106,31),Anchor=AnchorStyles.Top|AnchorStyles.Right};browse.Click+=(s,e)=>Choose();Controls.Add(browse);
      install=new Button {Text="Installer le francais",Location=new Point(24,185),Size=new Size(218,43),BackColor=Color.FromArgb(30,88,160),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};install.Click+=(s,e)=>Run(true);Controls.Add(install);
      restore=new Button {Text="Restaurer l'anglais",Location=new Point(258,185),Size=new Size(218,43)};restore.Click+=(s,e)=>Run(false);Controls.Add(restore);
      Controls.Add(new Label {Text="Fermez le jeu. L'installation sauvegarde le fichier anglais avant remplacement.",Location=new Point(24,239),Size=new Size(692,28),Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right});
      output=new TextBox {Location=new Point(24,274),Size=new Size(692,134),Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,BackColor=Color.White,Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right};Controls.Add(output);
      progress=new ProgressBar {Location=new Point(24,425),Size=new Size(692,12),Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right};Controls.Add(progress);
      status=new Label {Text="Pret.",Location=new Point(24,446),Size=new Size(692,26),Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right};Controls.Add(status);
      FormClosing+=(s,e)=>{if(working){e.Cancel=true;Log("Operation en cours : attendez sa fin avant de fermer.");}};
    }
    void Choose() {using(var dialog=new FolderBrowserDialog {Description="Selectionnez le dossier contenant Apocalypter.exe",SelectedPath=folder.Text,ShowNewFolderButton=false})if(dialog.ShowDialog(this)==DialogResult.OK)folder.Text=dialog.SelectedPath;}
    void Log(string message) {if(InvokeRequired){BeginInvoke(new Action<string>(Log),message);return;}output.AppendText(message+Environment.NewLine);status.Text=message;}
    void Busy(bool active) {working=active;folder.Enabled=browse.Enabled=install.Enabled=restore.Enabled=!active;progress.Style=active?ProgressBarStyle.Marquee:ProgressBarStyle.Blocks;progress.MarqueeAnimationSpeed=active?25:0;progress.Value=active?0:100;}
    void Run(bool french) {
      string game=folder.Text.Trim(),payload=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"patch-fr.dat.gz");
      if(game.Length==0){Choose();game=folder.Text.Trim();if(game.Length==0)return;}
      if(french&&!File.Exists(payload)){MessageBox.Show(this,"patch-fr.dat.gz est absent. Extrayez tout le ZIP dans le meme dossier.","Patch incomplet",MessageBoxButtons.OK,MessageBoxIcon.Error);return;}
      output.Clear();Busy(true);Log(french?"Preparation du francais...":"Preparation de la restauration...");
      new Thread(()=> {
        string error=null;
        try {if(french)PatchEngine.Install(game,payload,Log);else PatchEngine.Restore(game,Log);}
        catch(Exception ex){error=ex.Message;Log("ERREUR : "+error);}
        string result=error;
        BeginInvoke(new Action(()=>{Busy(false);if(result!=null){progress.Value=0;MessageBox.Show(this,result,"Operation interrompue",MessageBoxButtons.OK,MessageBoxIcon.Error);}}));
      }) {IsBackground=true}.Start();
    }
  }
  public static class Program {
    [STAThread] public static int Main(string[] args) {
      // Command line is also available for developer testing; no UI is created.
      if(args.Length>0) {
        try {
          if(args[0]=="--rebuild"&&args.Length==5)PatchEngine.Rebuild(args[1],args[2],args[3],args[4],Console.WriteLine);
          else if(args[0]=="--install"&&args.Length==3)PatchEngine.Install(args[1],args[2],Console.WriteLine);
          else if(args[0]=="--restore"&&args.Length==2)PatchEngine.Restore(args[1],Console.WriteLine);
          else throw new ArgumentException("Arguments inconnus.");
          return 0;
        }catch(Exception ex){Console.Error.WriteLine(ex.Message);return 1;}
      }
      Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainWindow());return 0;
    }
  }
}
