# Apocalypter - Patch francais

Version de test pour les fichiers Unity 2020.3.49f1 transmis dans cette conversation.
1 791 occurrences de texte sont modifiees dans level0, level1 et sharedassets1.assets.
Les nouvelles traductions sont sans accents. Les polices existantes sont conservees.

## Installer ou revenir a l'anglais

1. Fermer Apocalypter.
2. Extraire TOUT le ZIP dans un dossier, par exemple sur le Bureau. Ne pas lancer l'EXE directement depuis le ZIP.
3. Lancer Apocalypter_Patch_FR.exe.
4. Choisir le dossier qui contient Apocalypter.exe.
5. Cliquer sur **Installer le francais** et attendre le message de fin.
6. Lancer le jeu normalement.

Pour revenir a l'anglais, rouvrir le programme et cliquer sur **Restaurer l'anglais**.

La sauvegarde est conservee apres restauration. Ne pas la supprimer si tu veux pouvoir revenir a l'anglais.
Le petit fichier data.unity3d.etat-fr contient les empreintes qui permettent de verifier une restauration.
En dernier recours, jeu ferme, tu peux copier data.unity3d.avant-fr vers data.unity3d pour remettre l'original.

Le traitement du bundle peut durer plusieurs minutes. Prevoir plusieurs Go libres sur le disque du jeu :
le programme utilise une copie de travail, les donnees decompressees et le nouveau conteneur.
La fenetre reste utilisable pour suivre le journal, mais sa fermeture est bloquee pendant le traitement.

Le programme cible Windows avec .NET Framework 4.5 ou ulterieur. L'installation courante ne demande pas Python.
SharpCompress.dll, patch-fr.dat.gz et Apocalypter_Patch_FR.exe.config doivent rester a cote de l'EXE.
L'installateur ne modifie pas Assembly-CSharp.dll. Les fichiers Steam ne sont pas concernes par la traduction.



